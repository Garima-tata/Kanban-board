import React from 'react'

const UniqueColumns = () => {
  return (
    <div>UniqueColumns</div>
  )
}

export default UniqueColumns